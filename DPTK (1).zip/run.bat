@echo off
  setlocal
  chcp 65001 >nul
  cd /d "%~dp0"
  echo ========================================
  echo   DPTK - Dinamik Polimorfik Trafik Kamuflaji
  echo ========================================
  echo.
  echo Yonetici yetkisi gerekiyor (WinDivert surucusu icin).
  echo Eger UAC istemi cikarsa "Evet"e tikla.
  echo.
  dptk.exe %*
  set EXITCODE=%ERRORLEVEL%
  echo.
  echo ----------------------------------------
  echo  Cikis kodu: %EXITCODE%
  echo  Pencereyi kapatmak icin bir tusa bas...
  echo ----------------------------------------
  pause >nul
  endlocal
  