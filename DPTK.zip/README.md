# DPTK - Dinamik Polimorfik Trafik Kamuflajı

  ## Kurulum

  1. `dptk-windows-x64.zip` (ya da CI artifact) içinden tüm dosyaları **aynı klasöre** çıkart:
     - `dptk.exe`
     - `WinDivert.dll`
     - `WinDivert.sys`
     - `run.bat`
     - `TORE_TEKLONOJI_ARASTIRMA.cer` (opsiyonel)

  2. **Yönetici olarak çalıştır**: `run.bat` dosyasına çift tıkla. UAC penceresi çıkacak — "Evet"e bas.

     > WinDivert ağ trafiğini yakalamak için bir Windows sürücüsü yükler;
     > bu nedenle yönetici hakları **zorunludur**.

  ## "Bilinmeyen yayıncı" uyarısı hakkında

  Exe self-signed sertifika ile imzalanmıştır. Windows'un bu sertifikayı tanıyabilmesi için
  `TORE_TEKLONOJI_ARASTIRMA.cer` dosyasına sağ tıklayıp **"Sertifika Yükle" → "Yerel Bilgisayar"
  → "Güvenilen Kök Sertifika Yetkilileri"** seçeneğini kullanarak içe aktarın.

  Tam SmartScreen güveni için gerçek bir Code Signing CA sertifikası (Sectigo / SSL.com / DigiCert)
  gerekir.

  ## Build (geliştiriciler için)

  CI üzerinde GitHub Actions otomatik olarak Windows runner'da derler ve imzalar.
  Detaylar için `.github/workflows/build.yml` dosyasına bakın.

  Yerel derleme:
  ```
  cmake -B build -A x64 -DCMAKE_BUILD_TYPE=Release
  cmake --build build --config Release
  ```

  WinDivert 2.2.2 `third_party/WinDivert/` altında olmalı.
  