# DPTK — Dinamik Polimorfik Trafik Kamuflajı

ISP-seviyesi Derin Paket İnceleme (DPI) engellerini, **sıfır sunucu** ve **minimal gecikme** ile aşan bir Windows ağ aracı.  
WinDivert tabanlı user-space implementasyon — kernel driver kurulumu gerektirmez.

---

## Nasıl Çalışır?

| Bileşen | Açıklama |
|---|---|
| **DPI Bypass** | TLS ClientHello'daki SNI alanını ve HTTP `Host:` başlığını TCP segmentasyon ile böler. DPI cihazı yarım kayıtlar görür, sınıflandıramaz. |
| **Packet Mutator** | TTL, TCP window, ECN ve timestamp alanlarını gerçek OS davranışını taklit edecek şekilde rastgeleleştirir. |
| **Traffic Shaper** | Flow başına inter-paket gecikme profilini Netflix yayını / Windows Update gibi masum trafiklerle eşleştirir. |

Tüm işlem **lokal makinede** gerçekleşir; dış sunucu yoktur, VPN tüneli yoktur.

---

## Gereksinimler

- Windows 10/11 x64  
- Visual Studio 2022 (MSVC) veya MinGW-w64  
- CMake ≥ 3.20  
- **[WinDivert 2.x](https://reqrypt.org/windivert.html)** (aşağıya bakın)

---

## Kurulum

### 1. WinDivert İndir

```
https://reqrypt.org/windivert.html
```

Zip'i aç ve şu yapıyı oluştur:

```
DPTK/
└── third_party/
    └── WinDivert/
        ├── include/
        │   └── windivert.h
        └── x64/
            ├── WinDivert.lib
            ├── WinDivert.dll
            └── WinDivert.sys
```

### 2. Build

```powershell
# Developer PowerShell / x64 Native Tools Command Prompt
git clone https://github.com/YOUR_USERNAME/DPTK
cd DPTK

cmake -B build -A x64 -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release

# Çıktı: build/Release/dptk.exe
```

### 3. Çalıştır (Yönetici olarak)

```powershell
# Sağ tık → "Yönetici olarak çalıştır"
.\build\Release\dptk.exe

# Seçenekler:
.\dptk.exe --verbose          # Detaylı log
.\dptk.exe --threads 4        # Worker thread sayısı
.\dptk.exe --no-shape         # Traffic shaping'i kapat
.\dptk.exe --fake-ttl         # Sahte paket enjeksiyonu ekle (deneysel)
```

> **Not:** `WinDivert.dll` ve `WinDivert.sys`, `dptk.exe` ile aynı klasörde olmalıdır.  
> CMake build işlemi bunu otomatik kopyalar.

---

## Mimari

```
Giden Paket
    │
    ▼
┌─────────────────────────────────┐
│        WinDivert Intercept      │  (WINDIVERT_LAYER_NETWORK)
└────────────────┬────────────────┘
                 │
         ┌───────▼────────┐
         │   DpiBypass    │  TLS SNI / HTTP Host tespiti
         │                │  → TCP segmentasyon
         │                │  → (opsiyonel) sahte paket
         └───────┬────────┘
                 │
         ┌───────▼────────┐
         │ PacketMutator  │  TTL / Window / ECN / Timestamp
         └───────┬────────┘
                 │
         ┌───────▼────────┐
         │ TrafficShaper  │  Flow bazlı zamanlama jitter'ı
         └───────┬────────┘
                 │
    ┌────────────▼────────────┐
    │   WinDivert Re-inject   │
    └─────────────────────────┘
```

---

## Performans

| Ölçüm | Değer |
|---|---|
| Eklenen gecikme (mutasyon only) | < 0.1 ms |
| Eklenen gecikme (shaping açık) | 0 – 4 ms jitter (kasıtlı) |
| CPU kullanımı (idle) | ~0% |
| CPU kullanımı (1 Gbps trafik) | ~3–8% (4 thread) |

---

## Sorun Giderme

**`WinDivertOpen failed: 5` (Erişim Engellendi)**  
→ Yönetici olarak çalıştır.

**`WinDivertOpen failed: 577` (Driver imza hatası)**  
→ Güvenli Önyükleme etkinken bazı sistemlerde WinDivert sürücüsü yüklenemez.  
→ BIOS'tan Secure Boot'u geçici olarak devre dışı bırakabilir ya da  
   [test mode](https://learn.microsoft.com/en-us/windows-hardware/drivers/install/the-testsigning-boot-configuration-option)'u etkinleştirebilirsin.

**Oyun veya tarayıcı bağlanamıyor**  
→ `dptk.exe`yi kapatmak yeterli; WinDivert kendiliğinden trafiği serbest bırakır.

---

## Yasal Not

Bu araç yalnızca kendi ağ trafiğin üzerinde DPI gizleme amacıyla kullanım içindir.  
Başkalarına ait sistemlere, ağlara veya sunuculara yönelik kullanım bu projenin  
kapsamı dışındadır.

---

## Lisans

MIT
