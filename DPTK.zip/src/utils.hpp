#pragma once
  //
  // utils.hpp — shared logging helpers for DPTK
  //
  // Defines printf-style log macros (LOG_INFO / LOG_ERROR / LOG_DEBUG)
  // and the global verbose flag used across the project.
  //
  #include <cstdio>
  #include <cstdarg>
  #include <ctime>

  // Defined in dpi_bypass.cpp
  extern bool g_verbose;

  namespace dptk_log {

  inline void _emit(const char* level, const char* fmt, va_list ap) {
      std::time_t t = std::time(nullptr);
      std::tm tm{};
  #if defined(_WIN32)
      localtime_s(&tm, &t);
  #else
      localtime_r(&t, &tm);
  #endif
      char ts[32];
      std::strftime(ts, sizeof(ts), "%H:%M:%S", &tm);
      std::fprintf(stderr, "[%s] [%s] ", ts, level);
      std::vfprintf(stderr, fmt, ap);
      std::fputc('\n', stderr);
      std::fflush(stderr);
  }

  inline void info(const char* fmt, ...) {
      va_list ap; va_start(ap, fmt);
      _emit("INFO ", fmt, ap);
      va_end(ap);
  }

  inline void error(const char* fmt, ...) {
      va_list ap; va_start(ap, fmt);
      _emit("ERROR", fmt, ap);
      va_end(ap);
  }

  inline void debug(const char* fmt, ...) {
      if (!g_verbose) return;
      va_list ap; va_start(ap, fmt);
      _emit("DEBUG", fmt, ap);
      va_end(ap);
  }

  } // namespace dptk_log

  #define LOG_INFO(...)  ::dptk_log::info(__VA_ARGS__)
  #define LOG_ERROR(...) ::dptk_log::error(__VA_ARGS__)
  #define LOG_DEBUG(...) ::dptk_log::debug(__VA_ARGS__)
  