#pragma once
  //
  // utils.hpp — shared definitions, config types and helpers for DPTK
  //
  #include <windows.h>
  #include <windivert.h>
  #include <cstdio>
  #include <cstdarg>
  #include <ctime>
  #include <cstdint>
  #include <random>
  #include <chrono>
  #include <thread>

  // ── WinDivert compatibility shim ─────────────────────────────────────────────
  #ifndef WINDIVERT_INVALID_HANDLE
  #define WINDIVERT_INVALID_HANDLE INVALID_HANDLE_VALUE
  #endif

  // Defined in dpi_bypass.cpp
  extern bool g_verbose;

  // ── Configuration types ─────────────────────────────────────────────────────
  namespace Dptk {

  enum class FragMode : int {
      NONE        = 0,
      TCP_SEGMENT = 1 << 0,
      FAKE_PACKET = 1 << 1,
  };

  inline bool has(FragMode a, FragMode b) {
      return (static_cast<int>(a) & static_cast<int>(b)) != 0;
  }

  enum class MutationLevel : int {
      OFF      = 0,
      LIGHT    = 1,
      BALANCED = 2,
      HEAVY    = 3,
  };

  enum class ShapingProfile : int {
      NONE      = 0,
      STREAMING = 1,
      UPDATE    = 2,
      BROWSE    = 3,
  };

  struct Config {
      unsigned       threads          = 2;
      FragMode       frag_mode        = FragMode::TCP_SEGMENT;
      MutationLevel  mutation_level   = MutationLevel::BALANCED;
      ShapingProfile shaping_profile  = ShapingProfile::STREAMING;
      bool           verbose          = false;

      // Fragmentation tuning
      UINT           frag_split_min   = 1;
      UINT           frag_split_max   = 8;
      uint8_t        fake_ttl         = 4;
  };

  } // namespace Dptk

  // ── Privilege check ─────────────────────────────────────────────────────────
  inline bool dptk_is_elevated() {
      BOOL elevated = FALSE;
      HANDLE token = nullptr;
      if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) {
          TOKEN_ELEVATION elev{};
          DWORD sz = sizeof(elev);
          if (GetTokenInformation(token, TokenElevation, &elev, sizeof(elev), &sz)) {
              elevated = elev.TokenIsElevated;
          }
          CloseHandle(token);
      }
      return elevated == TRUE;
  }

  // ── Random helpers ──────────────────────────────────────────────────────────
  inline std::mt19937& dptk_rng() {
      static thread_local std::mt19937 rng{
          std::random_device{}() ^
          static_cast<uint32_t>(std::chrono::steady_clock::now().time_since_epoch().count())
      };
      return rng;
  }

  inline uint32_t rand_u32(uint32_t min_v, uint32_t max_v) {
      if (max_v <= min_v) return min_v;
      std::uniform_int_distribution<uint32_t> dist(min_v, max_v);
      return dist(dptk_rng());
  }

  // ── Precise sleep (sub-millisecond) ─────────────────────────────────────────
  inline void precise_sleep_us(uint32_t us) {
      if (us == 0) return;
      if (us >= 2000) {
          std::this_thread::sleep_for(std::chrono::microseconds(us));
          return;
      }
      // Busy-spin for sub-2ms delays for accuracy.
      auto target = std::chrono::steady_clock::now() + std::chrono::microseconds(us);
      while (std::chrono::steady_clock::now() < target) {
          YieldProcessor();
      }
  }

  // ── Logging helpers ─────────────────────────────────────────────────────────
  namespace dptk_log {

  inline void _emit(const char* level, const char* fmt, va_list ap) {
      std::time_t t = std::time(nullptr);
      std::tm tm{};
  #if defined(_WIN32)
      localtime_s(&tm, &t);
  #else
      localtime_r(&t, &tm);
  #endif
      char ts[32];
      std::strftime(ts, sizeof(ts), "%H:%M:%S", &tm);
      std::fprintf(stderr, "[%s] [%s] ", ts, level);
      std::vfprintf(stderr, fmt, ap);
      std::fputc('\n', stderr);
      std::fflush(stderr);
  }

  inline void info(const char* fmt, ...) {
      va_list ap; va_start(ap, fmt);
      _emit("INFO ", fmt, ap);
      va_end(ap);
  }

  inline void error(const char* fmt, ...) {
      va_list ap; va_start(ap, fmt);
      _emit("ERROR", fmt, ap);
      va_end(ap);
  }

  inline void debug(const char* fmt, ...) {
      if (!g_verbose) return;
      va_list ap; va_start(ap, fmt);
      _emit("DEBUG", fmt, ap);
      va_end(ap);
  }

  } // namespace dptk_log

  #define LOG_INFO(...)  ::dptk_log::info(__VA_ARGS__)
  #define LOG_ERROR(...) ::dptk_log::error(__VA_ARGS__)
  #define LOG_DEBUG(...) ::dptk_log::debug(__VA_ARGS__)
  