#include "dpi_bypass.hpp"
#include <winsock2.h>
#include <cstring>
#include <algorithm>

bool g_verbose = false;  // definition (declared extern in utils.hpp)

// ─── Detection ───────────────────────────────────────────────────────────────

bool DpiBypass::is_tls_client_hello(const uint8_t* d, UINT len)
{
    // TLS record header: ContentType=0x16 (Handshake), Version=0x03 0x0?
    // Handshake type byte: 0x01 (ClientHello)
    if (len < 6) return false;
    if (d[0] != 0x16) return false;
    if (d[1] != 0x03) return false;
    if (d[5] != 0x01) return false;   // handshake type = ClientHello
    return true;
}

bool DpiBypass::is_http_request(const uint8_t* d, UINT len)
{
    if (len < 4) return false;
    // Common HTTP verbs
    const char* verbs[] = {"GET ", "POST", "HEAD", "PUT ", "DELE", "OPTI", "PATC"};
    for (const char* v : verbs)
        if (memcmp(d, v, 4) == 0) return true;
    return false;
}

bool DpiBypass::needs_fragmentation(const void* payload, UINT len) const
{
    if (Dptk::has(cfg_.frag_mode, Dptk::FragMode::TCP_SEGMENT) == false)
        return false;
    const auto* d = static_cast<const uint8_t*>(payload);
    return is_tls_client_hello(d, len) || is_http_request(d, len);
}

// ─── Split-point finding ──────────────────────────────────────────────────────

/*
 * TLS ClientHello layout (simplified):
 *   [0]    ContentType    = 0x16
 *   [1-2]  Legacy version = 0x03 0x01
 *   [3-4]  Record length
 *   [5]    HandshakeType  = 0x01
 *   [6-8]  HS length (3 bytes)
 *   [9-10] ClientHello version
 *   [11-42] Random (32 bytes)
 *   [43]   SessionID length
 *   ...    CipherSuites, CompressionMethods, Extensions
 *
 * SNI extension type = 0x00 0x00
 * We split the payload right after the SNI extension type field, so that
 * both halves individually look malformed to a DPI engine.
 */
UINT DpiBypass::find_tls_split(const uint8_t* d, UINT len,
                                UINT split_min, UINT split_max)
{
    // Walk to extensions
    if (len < 44) goto fallback;
    {
        UINT pos = 43;
        if (pos >= len) goto fallback;
        UINT sid_len = d[pos++];
        pos += sid_len;
        if (pos + 2 > len) goto fallback;
        UINT cs_len = (d[pos] << 8) | d[pos + 1];
        pos += 2 + cs_len;
        if (pos + 1 > len) goto fallback;
        pos += 1 + d[pos];   // compression methods
        if (pos + 2 > len) goto fallback;
        UINT ext_total = (d[pos] << 8) | d[pos + 1];
        pos += 2;
        UINT ext_end = pos + ext_total;

        while (pos + 4 <= ext_end && pos + 4 <= len) {
            UINT ext_type = (d[pos] << 8) | d[pos + 1];
            UINT ext_len  = (d[pos + 2] << 8) | d[pos + 3];
            if (ext_type == 0x0000) {
                // Found SNI extension — split just past the type field
                UINT split = pos + 2;
                split = std::clamp(split, split_min, std::min(split_max, len - 1));
                return split;
            }
            pos += 4 + ext_len;
        }
    }
fallback:
    // No SNI found: split early in record, within the version/random area
    return std::clamp(rand_u32(split_min, split_max), 1u, len - 1);
}

UINT DpiBypass::find_http_split(const uint8_t* d, UINT len)
{
    // Find "Host:" header and split mid-hostname
    const char* needle = "Host:";
    UINT nlen = 5;
    for (UINT i = 0; i + nlen < len; ++i) {
        if (memcmp(d + i, needle, nlen) == 0) {
            // Split after "Ho" so neither fragment contains "Host:"
            return i + 2;
        }
    }
    // Fallback: split after the first line (after first \r\n)
    for (UINT i = 0; i + 1 < len; ++i)
        if (d[i] == '\r' && d[i+1] == '\n')
            return i + 2;
    return len / 2;
}

// ─── Segment injection ────────────────────────────────────────────────────────

bool DpiBypass::inject_segment(HANDLE handle,
                               WINDIVERT_ADDRESS addr,
                               PWINDIVERT_IPHDR   ip_hdr,
                               PWINDIVERT_IPV6HDR ip6_hdr,
                               PWINDIVERT_TCPHDR  tcp_hdr,
                               const uint8_t*     payload,
                               UINT               payload_off,
                               UINT               seg_len,
                               uint32_t           seq_delta,
                               bool               use_fake_ttl)
{
    if (seg_len == 0) return true;

    // Compute IP header length
    UINT ip_hdr_len = ip_hdr ? (ip_hdr->HdrLength * 4u) : 40u;
    UINT tcp_hdr_len = tcp_hdr->HdrLength * 4u;

    UINT total = ip_hdr_len + tcp_hdr_len + seg_len;
    std::vector<uint8_t> pkt(total, 0);

    // Copy IP header
    if (ip_hdr) {
        memcpy(pkt.data(), ip_hdr, ip_hdr_len);
        auto* new_ip = reinterpret_cast<PWINDIVERT_IPHDR>(pkt.data());
        new_ip->Length = htons(static_cast<uint16_t>(total));
        if (use_fake_ttl)
            new_ip->TTL = cfg_.fake_ttl;
    }

    // Copy TCP header
    uint8_t* tcp_dest = pkt.data() + ip_hdr_len;
    memcpy(tcp_dest, tcp_hdr, tcp_hdr_len);
    auto* new_tcp = reinterpret_cast<PWINDIVERT_TCPHDR>(tcp_dest);

    // Adjust sequence number
    uint32_t new_seq = ntohl(tcp_hdr->SeqNum) + seq_delta;
    new_tcp->SeqNum = htonl(new_seq);

    // Copy payload slice
    memcpy(pkt.data() + ip_hdr_len + tcp_hdr_len,
           payload + payload_off, seg_len);

    // Recalculate checksums
    WinDivertHelperCalcChecksums(pkt.data(), total, &addr, 0);

    UINT sent = 0;
    return WinDivertSend(handle, pkt.data(), total, &sent, &addr) == TRUE;
}

// ─── Public: send_fragmented ─────────────────────────────────────────────────

bool DpiBypass::send_fragmented(HANDLE handle,
                                const void*        raw_packet,
                                UINT               raw_len,
                                WINDIVERT_ADDRESS  addr,
                                PWINDIVERT_IPHDR   ip_hdr,
                                PWINDIVERT_IPV6HDR ip6_hdr,
                                PWINDIVERT_TCPHDR  tcp_hdr,
                                const void*        payload,
                                UINT               payload_len)
{
    const auto* pd = static_cast<const uint8_t*>(payload);
    bool is_tls  = is_tls_client_hello(pd, payload_len);

    // Find split position
    UINT split = is_tls
        ? find_tls_split(pd, payload_len, cfg_.frag_split_min, cfg_.frag_split_max)
        : find_http_split(pd, payload_len);

    if (split == 0 || split >= payload_len)
        split = std::clamp(payload_len / 3, 1u, payload_len - 1);

    bool fake_ttl = Dptk::has(cfg_.frag_mode, Dptk::FragMode::FAKE_PACKET);

    // Optionally inject fake (dead) segment carrying the split boundary
    if (fake_ttl) {
        // A fake packet with TTL too short to reach the server.
        // DPI sees it and stores state, but the server never gets it,
        // so the DPI state machine is poisoned.
        inject_segment(handle, addr, ip_hdr, ip6_hdr, tcp_hdr,
                       pd, 0, payload_len,
                       0, /* use_fake_ttl */ true);
    }

    // First real segment: [0, split)
    bool ok = inject_segment(handle, addr, ip_hdr, ip6_hdr, tcp_hdr,
                             pd, 0, split, 0, false);

    // Second real segment: [split, payload_len)
    ok &= inject_segment(handle, addr, ip_hdr, ip6_hdr, tcp_hdr,
                         pd, split, payload_len - split, split, false);

    LOG_DEBUG("Fragmented %s payload %u bytes at offset %u",
              is_tls ? "TLS" : "HTTP", payload_len, split);
    return ok;
}
