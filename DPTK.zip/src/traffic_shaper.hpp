#pragma once
#include <windivert.h>
#include <chrono>
#include <unordered_map>
#include <mutex>
#include "utils.hpp"

/*
 * TrafficShaper
 * ─────────────
 * Manipulates per-flow inter-packet timing to match innocent traffic profiles.
 *
 * DPI traffic classifiers that detect games / P2P / "unusual" applications
 * often rely on flow-level statistics:
 *   - inter-arrival time distributions
 *   - packet size distributions
 *   - burst length / pause patterns
 *
 * By adding calibrated micro-delays we can make a game flow look like
 * an HTTPS streaming session or a background Windows update.
 *
 * Profiles
 * ────────
 * STREAMING : add 0–4 ms jitter per packet; burst 8–32 packets then
 *             "pause" 40–120 ms (mimics streaming segment fetch pattern)
 * UPDATE    : large steady bursts with minimal per-packet delay (1–2 ms)
 * BROWSE    : short bursts (2–8 packets) with 10–80 ms pauses between
 *
 * Flow tracking key: (src_ip, dst_ip, src_port, dst_port, proto)
 * To avoid unbounded memory growth, flows idle for >30 s are evicted.
 */

struct FlowKey {
    uint32_t src_ip, dst_ip;
    uint16_t src_port, dst_port;
    uint8_t  proto;

    bool operator==(const FlowKey& o) const {
        return src_ip == o.src_ip && dst_ip == o.dst_ip &&
               src_port == o.src_port && dst_port == o.dst_port &&
               proto == o.proto;
    }
};

struct FlowKeyHash {
    size_t operator()(const FlowKey& k) const {
        size_t h = k.src_ip;
        h ^= k.dst_ip  * 0x9e3779b9UL + (h << 6) + (h >> 2);
        h ^= (k.src_port | (k.dst_port << 16)) * 0x517cc1b727220a95ULL;
        h ^= k.proto;
        return h;
    }
};

struct FlowState {
    uint32_t burst_count = 0;
    uint32_t burst_target = 0;    // how many packets before a pause
    std::chrono::steady_clock::time_point last_seen{};
};

class TrafficShaper
{
public:
    explicit TrafficShaper(const Dptk::Config& cfg) : cfg_(cfg) {}

    // Optionally delay the calling thread based on the flow's shaping profile.
    // Call this BEFORE injecting the packet.
    void apply_jitter(const WINDIVERT_ADDRESS& addr,
                      PWINDIVERT_TCPHDR tcp_hdr,
                      PWINDIVERT_UDPHDR udp_hdr);

private:
    const Dptk::Config& cfg_;
    std::mutex          mu_;
    std::unordered_map<FlowKey, FlowState, FlowKeyHash> flows_;

    FlowState& get_or_create(const FlowKey& k);
    void       evict_stale();

    static FlowKey make_key(const WINDIVERT_ADDRESS& addr,
                            PWINDIVERT_TCPHDR tcp,
                            PWINDIVERT_UDPHDR udp);

    // Returns delay in microseconds for current packet
    uint32_t compute_delay_us(FlowState& fs);
};
