/*
 * DPTK - Dinamik Polimorfik Trafik Kamuflaji
 * DPI-based censorship bypass tool using WinDivert
 *
 * Build: See CMakeLists.txt
 * Requires: WinDivert 2.x (https://reqrypt.org/windivert.html)
 * Run as Administrator.
 */

#include <winsock2.h>
#include <windows.h>
#include <windivert.h>
#include <iostream>
#include <thread>
#include <atomic>
#include <csignal>

#include "dpi_bypass.hpp"
#include "packet_mutator.hpp"
#include "traffic_shaper.hpp"
#include "utils.hpp"

#pragma comment(lib, "WinDivert.lib")
#pragma comment(lib, "ws2_32.lib")

// ─── Global state ────────────────────────────────────────────────────────────
static std::atomic<bool> g_running{true};
static HANDLE            g_handle = WINDIVERT_INVALID_HANDLE;

// ─── Signal handler ──────────────────────────────────────────────────────────
static void signal_handler(int)
{
    g_running.store(false);
    if (g_handle != WINDIVERT_INVALID_HANDLE)
        WinDivertShutdown(g_handle, WINDIVERT_SHUTDOWN_BOTH);
    LOG_INFO("Shutting down DPTK…");
}

// ─── Worker thread ───────────────────────────────────────────────────────────
void worker_thread(HANDLE handle, DpiBypass& bypass, PacketMutator& mutator,
                   TrafficShaper& shaper, int thread_id)
{
    constexpr UINT MAX_PKT = 65535 + 96;   // max IP packet + WinDivert overhead
    std::vector<BYTE> buf(MAX_PKT);

    WINDIVERT_ADDRESS addr{};
    UINT              recv_len = 0;

    while (g_running.load(std::memory_order_relaxed))
    {
        recv_len = 0;
        if (!WinDivertRecv(handle, buf.data(), static_cast<UINT>(buf.size()),
                           &recv_len, &addr))
        {
            if (GetLastError() == ERROR_NO_DATA || !g_running.load())
                break;
            continue;
        }

        // Parse headers
        PWINDIVERT_IPHDR   ip_hdr  = nullptr;
        PWINDIVERT_IPV6HDR ip6_hdr = nullptr;
        PWINDIVERT_TCPHDR  tcp_hdr = nullptr;
        PWINDIVERT_UDPHDR  udp_hdr = nullptr;
        PVOID              payload = nullptr;
        UINT               payload_len = 0;

        WinDivertHelperParsePacket(buf.data(), recv_len,
                                   &ip_hdr, &ip6_hdr, nullptr, nullptr,
                                   nullptr, &tcp_hdr, &udp_hdr,
                                   &payload, &payload_len,
                                   nullptr, nullptr);

        bool modified = false;

        // Only process OUTBOUND packets
        if (addr.Outbound)
        {
            // 1. DPI bypass: fragment TLS ClientHello SNI, HTTP Host, etc.
            if (tcp_hdr && payload && payload_len > 0)
            {
                if (bypass.needs_fragmentation(payload, payload_len))
                {
                    bypass.send_fragmented(handle, buf.data(), recv_len, addr,
                                          ip_hdr, ip6_hdr, tcp_hdr,
                                          payload, payload_len);
                    continue;  // fragments already sent
                }
            }

            // 2. Packet mutation: add noise, randomise TTL/window, etc.
            modified |= mutator.mutate(buf.data(), recv_len,
                                       ip_hdr, ip6_hdr, tcp_hdr, udp_hdr,
                                       payload, payload_len);

            // 3. Traffic shaping: timing jitter to spoof flow signature
            shaper.apply_jitter(addr, tcp_hdr, udp_hdr);
        }

        // Recalculate checksums if we changed anything
        if (modified)
            WinDivertHelperCalcChecksums(buf.data(), recv_len, &addr, 0);

        // Re-inject
        UINT send_len = 0;
        WinDivertSend(handle, buf.data(), recv_len, &send_len, &addr);
    }

    LOG_INFO("Worker thread %d exiting.", thread_id);
}

// ─── main ────────────────────────────────────────────────────────────────────
int main(int argc, char* argv[])
{
    // Print banner
    std::cout <<
        "\n"
        "  ██████╗ ██████╗ ████████╗██╗  ██╗\n"
        "  ██╔══██╗██╔══██╗╚══██╔══╝██║ ██╔╝\n"
        "  ██║  ██║██████╔╝   ██║   █████╔╝ \n"
        "  ██║  ██║██╔═══╝    ██║   ██╔═██╗ \n"
        "  ██████╔╝██║        ██║   ██║  ██╗\n"
        "  ╚═════╝ ╚═╝        ╚═╝   ╚═╝  ╚═╝\n"
        "  Dinamik Polimorfik Trafik Kamuflaји v1.0\n\n";

    // Parse CLI options
    Dptk::Config cfg;
    cfg.threads          = std::max(1u, std::thread::hardware_concurrency() / 2);
    cfg.frag_mode        = Dptk::FragMode::TCP_SEGMENT;
    cfg.mutation_level   = Dptk::MutationLevel::BALANCED;
    cfg.shaping_profile  = Dptk::ShapingProfile::STREAMING;
    cfg.verbose          = false;

    for (int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if (arg == "--verbose" || arg == "-v")  cfg.verbose = true;
        if (arg == "--threads" && i + 1 < argc) cfg.threads = std::atoi(argv[++i]);
        if (arg == "--no-shape")                cfg.shaping_profile = Dptk::ShapingProfile::NONE;
        if (arg == "--fake-ttl") {
            cfg.frag_mode = static_cast<Dptk::FragMode>(
                static_cast<int>(cfg.frag_mode) | static_cast<int>(Dptk::FragMode::FAKE_PACKET));
        }
        if (arg == "--help") {
            std::cout <<
                "Usage: dptk [options]\n"
                "  -v, --verbose       Verbose logging\n"
                "  --threads N         Worker threads (default: auto)\n"
                "  --no-shape          Disable traffic shaping\n"
                "  --fake-ttl          Enable fake-packet TTL injection\n\n";
            return 0;
        }
    }

    // Check admin
    if (!dptk_is_elevated()) {
        LOG_ERROR("DPTK must be run as Administrator.");
        return 1;
    }

    // Register signals
    std::signal(SIGINT,  signal_handler);
    std::signal(SIGTERM, signal_handler);

    // WinDivert filter: intercept all TCP and UDP at the network layer
    // Exclude loopback to avoid processing our own injected packets
    const char* filter =
        "(tcp or udp) and not loopback";

    g_handle = WinDivertOpen(filter, WINDIVERT_LAYER_NETWORK,
                             /* priority */ 0,
                             WINDIVERT_FLAG_FRAGMENTS);
    if (g_handle == WINDIVERT_INVALID_HANDLE) {
        LOG_ERROR("WinDivertOpen failed: %lu", GetLastError());
        LOG_ERROR("Ensure WinDivert driver is installed and you are running as Admin.");
        return 1;
    }

    // Tune WinDivert queue for high throughput
    WinDivertSetParam(g_handle, WINDIVERT_PARAM_QUEUE_LENGTH,  8192);
    WinDivertSetParam(g_handle, WINDIVERT_PARAM_QUEUE_SIZE,    33554432);  // 32 MB
    WinDivertSetParam(g_handle, WINDIVERT_PARAM_QUEUE_TIME,    2000);

    LOG_INFO("DPTK active — %u worker thread(s)", cfg.threads);
    LOG_INFO("Filter : %s", filter);
    LOG_INFO("Press Ctrl+C to stop.\n");

    // Construct processing components
    DpiBypass     bypass(cfg);
    PacketMutator mutator(cfg);
    TrafficShaper shaper(cfg);

    // Spawn worker threads (each thread owns its own handle clone via
    // WINDIVERT_FLAG_RECV_ONLY / SEND_ONLY for true parallelism;
    // for simplicity we share the handle — WinDivert is thread-safe for
    // concurrent Recv/Send on the same handle)
    std::vector<std::thread> workers;
    workers.reserve(cfg.threads);
    for (unsigned i = 0; i < cfg.threads; ++i)
        workers.emplace_back(worker_thread, g_handle,
                             std::ref(bypass), std::ref(mutator),
                             std::ref(shaper), static_cast<int>(i));

    for (auto& t : workers)
        t.join();

    WinDivertClose(g_handle);
    LOG_INFO("DPTK stopped cleanly.");
    return 0;
}
