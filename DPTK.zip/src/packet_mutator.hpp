#pragma once
#include <windivert.h>
#include "utils.hpp"

/*
 * PacketMutator
 * ─────────────
 * Applies per-packet mutations to disguise traffic fingerprints:
 *
 *  LIGHT:
 *    • Randomise IP TTL within a plausible OS range (64±8 or 128±8)
 *
 *  BALANCED (default):
 *    • LIGHT  +
 *    • Randomise TCP window size from a pool of real-OS values
 *    • Randomly enable/disable TCP ECN flags
 *    • Add random TCP timestamp jitter (if option present)
 *
 *  HEAVY:
 *    • BALANCED +
 *    • Stuff TCP options with NOP padding to shift header boundaries
 *    • Randomise IP Identification field
 *    • Flip DSCP/ECN bits in IP ToS to mimic streaming QoS markers
 *
 * None of these changes break the connection:
 *   - TTL changes stay well above 1 so the packet reaches its destination.
 *   - Window changes are within legal values.
 *   - NOP option stuffing is explicitly defined in RFC 793.
 *   - Checksums are always recalculated by the caller.
 */

class PacketMutator
{
public:
    explicit PacketMutator(const Dptk::Config& cfg) : cfg_(cfg) {}

    // Mutate packet in-place.  Returns true if the packet was modified.
    bool mutate(uint8_t*           raw,
                UINT               raw_len,
                PWINDIVERT_IPHDR   ip_hdr,
                PWINDIVERT_IPV6HDR ip6_hdr,
                PWINDIVERT_TCPHDR  tcp_hdr,
                PWINDIVERT_UDPHDR  udp_hdr,
                void*              payload,
                UINT               payload_len);

private:
    const Dptk::Config& cfg_;

    bool mutate_ip_ttl(PWINDIVERT_IPHDR ip_hdr);
    bool mutate_ip_tos(PWINDIVERT_IPHDR ip_hdr);
    bool mutate_ip_id (PWINDIVERT_IPHDR ip_hdr);
    bool mutate_tcp_window(PWINDIVERT_TCPHDR tcp_hdr);
    bool mutate_tcp_ecn   (PWINDIVERT_TCPHDR tcp_hdr);
    bool mutate_tcp_timestamp(PWINDIVERT_TCPHDR tcp_hdr, UINT tcp_hdr_len);

    // Realistic window sizes from Windows/Linux/macOS initial handshakes
    static const uint16_t k_window_pool[];
    static const int      k_window_pool_size;
};
