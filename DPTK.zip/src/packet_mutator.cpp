#include "packet_mutator.hpp"
#include <winsock2.h>
#include <cstring>

// Pool of TCP window sizes observed from real OS initial handshakes
const uint16_t PacketMutator::k_window_pool[] = {
    8192, 16384, 32768, 65535,
    // macOS
    65535,
    // Linux kernel defaults
    29200, 43690,
    // Windows 10/11
    64240, 65535,
    // Android
    14600, 29200,
};
const int PacketMutator::k_window_pool_size =
    sizeof(k_window_pool) / sizeof(k_window_pool[0]);

// ─── IP mutations ─────────────────────────────────────────────────────────────

bool PacketMutator::mutate_ip_ttl(PWINDIVERT_IPHDR h)
{
    if (!h) return false;
    // Keep TTL within plausible OS-emitted ranges:
    //   Windows: 128, Linux: 64, macOS: 64.
    // We pick one of those base values and add small jitter.
    uint8_t bases[] = {64, 128};
    uint8_t base    = bases[rand_u32(0, 1)];
    int8_t  jitter  = static_cast<int8_t>(rand_u32(0, 12)) - 6; // [-6, +6]
    uint8_t new_ttl = static_cast<uint8_t>(
        std::clamp(static_cast<int>(base) + jitter, 32, 255));
    if (h->TTL == new_ttl) return false;
    h->TTL = new_ttl;
    return true;
}

bool PacketMutator::mutate_ip_tos(PWINDIVERT_IPHDR h)
{
    if (!h) return false;
    // Streaming services commonly use DSCP CS1 (0x20) or EF (0xB8).
    // We occasionally set one of those to blend in.
    static const uint8_t tos_pool[] = {0x00, 0x00, 0x00, 0x20, 0xB8};
    uint8_t new_tos = tos_pool[rand_u32(0, 4)];
    if (h->TOS == new_tos) return false;
    h->TOS = new_tos;
    return true;
}

bool PacketMutator::mutate_ip_id(PWINDIVERT_IPHDR h)
{
    if (!h) return false;
    h->Id = htons(static_cast<uint16_t>(rand_u32(1, 65535)));
    return true;
}

// ─── TCP mutations ────────────────────────────────────────────────────────────

bool PacketMutator::mutate_tcp_window(PWINDIVERT_TCPHDR h)
{
    if (!h) return false;
    // Only mutate if window scaling option is NOT present (heuristic: small header)
    // Changing window on an established connection can confuse the peer;
    // we only do it on SYN packets where it is safe.
    if (!h->Syn) return false;
    uint16_t w = k_window_pool[rand_u32(0, k_window_pool_size - 1)];
    if (h->Window == htons(w)) return false;
    h->Window = htons(w);
    return true;
}

bool PacketMutator::mutate_tcp_ecn(PWINDIVERT_TCPHDR h)
{
    if (!h) return false;
    // Randomly toggle ECE bit to mimic ECN-capable endpoints
    if (rand_u32(0, 3) == 0) {
        h->Reserved1 ^= 0x1;  // ECE bit lives in Reserved1 nibble
        return true;
    }
    return false;
}

bool PacketMutator::mutate_tcp_timestamp(PWINDIVERT_TCPHDR h, UINT tcp_hdr_len)
{
    if (!h) return false;
    if (tcp_hdr_len < 24) return false;

    // Walk TCP options looking for timestamp option (kind=8)
    uint8_t* opts = reinterpret_cast<uint8_t*>(h) + 20;
    UINT     opts_len = tcp_hdr_len - 20;
    UINT     i = 0;
    while (i < opts_len) {
        uint8_t kind = opts[i];
        if (kind == 0) break;           // EOL
        if (kind == 1) { ++i; continue; } // NOP
        if (i + 1 >= opts_len) break;
        uint8_t len = opts[i + 1];
        if (len < 2 || i + len > opts_len) break;

        if (kind == 8 && len == 10) {
            // Timestamp value is at opts[i+2..i+5]
            uint32_t ts;
            memcpy(&ts, opts + i + 2, 4);
            ts = htonl(ntohl(ts) + rand_u32(0, 150)); // small jitter
            memcpy(opts + i + 2, &ts, 4);
            return true;
        }
        i += len;
    }
    return false;
}

// ─── Main mutate ─────────────────────────────────────────────────────────────

bool PacketMutator::mutate(uint8_t* raw, UINT raw_len,
                           PWINDIVERT_IPHDR ip_hdr, PWINDIVERT_IPV6HDR ip6_hdr,
                           PWINDIVERT_TCPHDR tcp_hdr, PWINDIVERT_UDPHDR udp_hdr,
                           void* payload, UINT payload_len)
{
    if (cfg_.mutation_level == Dptk::MutationLevel::OFF)
        return false;

    bool modified = false;

    // ── LIGHT ────────────────────────────────────────────────────────────────
    // TTL randomisation (only IPv4; IPv6 hop limit left intact)
    if (ip_hdr)
        modified |= mutate_ip_ttl(ip_hdr);

    if (cfg_.mutation_level == Dptk::MutationLevel::LIGHT)
        return modified;

    // ── BALANCED ─────────────────────────────────────────────────────────────
    if (tcp_hdr) {
        modified |= mutate_tcp_window(tcp_hdr);
        modified |= mutate_tcp_ecn(tcp_hdr);
        UINT tcp_hdr_len = tcp_hdr->HdrLength * 4u;
        modified |= mutate_tcp_timestamp(tcp_hdr, tcp_hdr_len);
    }

    if (cfg_.mutation_level == Dptk::MutationLevel::BALANCED)
        return modified;

    // ── HEAVY ────────────────────────────────────────────────────────────────
    if (ip_hdr) {
        modified |= mutate_ip_tos(ip_hdr);
        modified |= mutate_ip_id(ip_hdr);
    }

    return modified;
}
