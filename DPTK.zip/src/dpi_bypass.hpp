#pragma once
#include <windivert.h>
#include <vector>
#include <cstdint>
#include "utils.hpp"

/*
 * DpiBypass
 * ─────────
 * Detects and handles packets that carry DPI-visible protocol signatures:
 *   • TLS  ClientHello  (contains plaintext SNI hostname)
 *   • HTTP GET/POST/HOST  header lines
 *
 * Strategy
 * ────────
 * TCP segmentation: Split the first data segment that carries the sensitive
 * bytes into two pieces at a position *inside* the sensitive field, then send
 * them sequentially.  The OS TCP stack at the destination reassembles them
 * correctly, but mid-flow DPI appliances that inspect only the first segment
 * see an incomplete/garbled signature and cannot classify it.
 *
 * Optionally, a "fake" first segment (with a short TTL so it dies before the
 * server) is injected before the real data, further confusing stateful DPI.
 */

class DpiBypass
{
public:
    explicit DpiBypass(const Dptk::Config& cfg) : cfg_(cfg) {}

    // Returns true if the payload warrants fragmentation.
    bool needs_fragmentation(const void* payload, UINT payload_len) const;

    // Sends the packet as two (or more) TCP segments.
    // Returns false on send error.
    bool send_fragmented(HANDLE          handle,
                         const void*     raw_packet,
                         UINT            raw_len,
                         WINDIVERT_ADDRESS addr,
                         PWINDIVERT_IPHDR   ip_hdr,
                         PWINDIVERT_IPV6HDR ip6_hdr,
                         PWINDIVERT_TCPHDR  tcp_hdr,
                         const void*        payload,
                         UINT               payload_len);

private:
    const Dptk::Config& cfg_;

    // Detect TLS record: 0x16 0x03 0x0?  (handshake, TLS 1.x)
    static bool is_tls_client_hello(const uint8_t* data, UINT len);

    // Detect HTTP request verb
    static bool is_http_request(const uint8_t* data, UINT len);

    // Find split point inside SNI extension of a TLS ClientHello
    static UINT find_tls_split(const uint8_t* data, UINT len,
                                UINT split_min, UINT split_max);

    // Find split point inside HTTP "Host:" header
    static UINT find_http_split(const uint8_t* data, UINT len);

    // Low-level: craft and inject a TCP segment carrying [payload+off .. off+seg_len)
    bool inject_segment(HANDLE handle,
                        WINDIVERT_ADDRESS addr,
                        PWINDIVERT_IPHDR   ip_hdr,
                        PWINDIVERT_IPV6HDR ip6_hdr,
                        PWINDIVERT_TCPHDR  tcp_hdr,
                        const uint8_t* payload,
                        UINT payload_off,
                        UINT seg_len,
                        uint32_t seq_delta,
                        bool use_fake_ttl);
};
