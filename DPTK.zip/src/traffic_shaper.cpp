#include "traffic_shaper.hpp"
#include <winsock2.h>
#include <algorithm>

using Clock = std::chrono::steady_clock;

// ─── Flow management ──────────────────────────────────────────────────────────

FlowKey TrafficShaper::make_key(const WINDIVERT_ADDRESS& addr,
                                PWINDIVERT_TCPHDR tcp,
                                PWINDIVERT_UDPHDR udp)
{
    FlowKey k{};
    // addr contains parsed network address info
    if (addr.IPv6) {
        // For IPv6 use lower 32 bits of src/dst as a rough key
        // (full IPv6 key would need 128-bit hash, good enough for shaping)
        k.src_ip = addr.Flow.LocalAddr[3];
        k.dst_ip = addr.Flow.RemoteAddr[3];
    } else {
        k.src_ip = addr.Flow.LocalAddr[0];
        k.dst_ip = addr.Flow.RemoteAddr[0];
    }
    if (tcp) {
        k.src_port = ntohs(tcp->SrcPort);
        k.dst_port = ntohs(tcp->DstPort);
        k.proto    = 6;
    } else if (udp) {
        k.src_port = ntohs(udp->SrcPort);
        k.dst_port = ntohs(udp->DstPort);
        k.proto    = 17;
    }
    return k;
}

FlowState& TrafficShaper::get_or_create(const FlowKey& k)
{
    auto it = flows_.find(k);
    if (it == flows_.end()) {
        FlowState fs;
        fs.burst_target = rand_u32(8, 32);   // streaming-ish default
        fs.last_seen    = Clock::now();
        auto [ins, _] = flows_.emplace(k, fs);
        return ins->second;
    }
    return it->second;
}

void TrafficShaper::evict_stale()
{
    // Run eviction roughly every 1024 calls (cheap gate)
    static thread_local uint32_t counter = 0;
    if (++counter < 1024) return;
    counter = 0;

    auto now = Clock::now();
    for (auto it = flows_.begin(); it != flows_.end(); ) {
        auto age = std::chrono::duration_cast<std::chrono::seconds>(
                       now - it->second.last_seen).count();
        it = (age > 30) ? flows_.erase(it) : std::next(it);
    }
}

// ─── Delay computation ────────────────────────────────────────────────────────

uint32_t TrafficShaper::compute_delay_us(FlowState& fs)
{
    if (cfg_.shaping_profile == Dptk::ShapingProfile::NONE)
        return 0;

    fs.burst_count++;

    switch (cfg_.shaping_profile)
    {
    case Dptk::ShapingProfile::STREAMING:
    {
        // Per-packet jitter: 0–3 ms
        uint32_t delay = rand_u32(0, 3000);

        // After burst_target packets, insert a longer pause
        if (fs.burst_count >= fs.burst_target) {
            delay += rand_u32(40000, 120000);  // 40–120 ms segment pause
            fs.burst_count  = 0;
            fs.burst_target = rand_u32(8, 32);
        }
        return delay;
    }

    case Dptk::ShapingProfile::UPDATE:
    {
        // Steady large burst: 0–2 ms per packet, no pauses
        return rand_u32(0, 2000);
    }

    case Dptk::ShapingProfile::BROWSE:
    {
        // Short bursts (2–8 pkts) with longer inter-burst pauses (10–80 ms)
        uint32_t delay = rand_u32(0, 500);
        if (fs.burst_count >= fs.burst_target) {
            delay += rand_u32(10000, 80000);
            fs.burst_count  = 0;
            fs.burst_target = rand_u32(2, 8);
        }
        return delay;
    }

    default:
        return 0;
    }
}

// ─── Public: apply_jitter ────────────────────────────────────────────────────

void TrafficShaper::apply_jitter(const WINDIVERT_ADDRESS& addr,
                                 PWINDIVERT_TCPHDR tcp_hdr,
                                 PWINDIVERT_UDPHDR udp_hdr)
{
    if (cfg_.shaping_profile == Dptk::ShapingProfile::NONE)
        return;

    FlowKey k = make_key(addr, tcp_hdr, udp_hdr);

    uint32_t delay_us = 0;
    {
        std::lock_guard<std::mutex> lk(mu_);
        FlowState& fs = get_or_create(k);
        fs.last_seen  = Clock::now();
        delay_us      = compute_delay_us(fs);
        evict_stale();
    }

    if (delay_us > 0)
        precise_sleep_us(delay_us);
}
